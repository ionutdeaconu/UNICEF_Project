<meta name="google-signin-client_id" content="1072977554166-st43ulc96co7ldgmc609fvukufj67c0h.apps.googleusercontent.com">

<script src="https://apis.google.com/js/platform.js" async defer></script>