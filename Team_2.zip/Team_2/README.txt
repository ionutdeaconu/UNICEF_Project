Make sure to change paypal URLS to your website in Payments.php
Also, when testing real PayPal accounts, take off the 'sandbox' part in all the URLS inside Sandbox. 

Resources in case extra debugging is needed: http://www.evoluted.net/thinktank/web-development/paypal-php-integration
For Google Sign in: https://developers.google.com/identity/sign-in/web/sign-in
The relevant goolgle folders are labeled as such: googlefunctions googlesignin and in the sidebar we have the modal that brings it up. 

Media Upload supports ONLY ZIP FILES!

Finally MAKE SURE TO EDIT connectdb.php to account for your personal DATABASE!!

GitHub repository: https://github.com/ionutdeaconu/UNICEF_Project/blob/master/Team_2.zip
