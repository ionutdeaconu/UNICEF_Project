<?php

$has_session = session_status() == PHP_SESSION_ACTIVE;

if (!($has_session)){
	session_start();
	//echo 'New session started';
}

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '740187895905-oo613d94s06ug4l3qvtnebl5skjuqv0d.apps.googleusercontent.com';
$clientSecret = 'aA0Eh7btyigwK1Qduq8yCR9H';
$redirectURL = 'http://moonlightenginedemo.azurewebsites.net/saqibv1/index.php';

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to Moonlight');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>