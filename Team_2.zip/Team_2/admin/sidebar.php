<!DOCTYPE html> 

	
<div id="wrapper" class="toggled">

	<!-- Sidebar -->
	<div id="sidebar-wrapper">
		<ul class="sidebar-nav">
			<li class="sidebar-brand">
				<a href="index.php"  id="element1">
					MoonLight Engine
				</a>
			</li>
			<li>
				<a href="index.php"   id="element2">Home</a>
			</li>
			<li>
				<a href="eventList.php"   id="element3">Events</a>
			</li>
			<li>
				<a href="eventform.php"   id="element4">Add Event</a>
			</li>
			<li>
				<a href="changePassword.php"   id="element5">Change your Password</a>
			</li>
			<li>
				<a href="newUser.php"   id="element6">Add New User</a>
			</li>
            <li>
                <a href="../index.php"   id="element7">Exit Admin Portal</a>
            </li>
            <li>
                <a  id="element10">
                    <span class="glyphicon glyphicon-chevron-left center-icons" id="menu-toggle"></span> Hide Sidebar
                </a>

            </li>




				

                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

</html>      