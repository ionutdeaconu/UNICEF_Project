<!DOCTYPE html>
<html lang="en">

 <!-- Sidebar -->
        <?php 
		include 'sidebar.php';
		include '../connectdb.php';
		?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


    
    <title>Home</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    

       

        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
       
        
            <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        
                        <!-- PUT CONTENT HERE-->
                        <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

	
	<?php
	
					
	$sql = "SELECT * FROM events WHERE FeaturedEvent = '1'";
	$result = $db->query($sql);
	
	$count = mysqli_num_rows($result);
	$i = 0;
	if ($count == 0){
		echo '<img class ="img-responsive banner-img" src="../Images/EventBanner.png">';
	}
	echo '
		<!-- Wrapper for slides -->
		<div class="carousel-inner" role="listbox">';
	while($row = $result->fetch_assoc()) {
		$i +=1;
		if ($i==1){
			echo '<div class="item active">';
		}
		else{
			echo '<div class="item">';
		}
		echo '
			<img src="../'.$row['BannerImage'].'" alt="Image">
			<div class="carousel-caption">
			  <h1>'.$row['EventName'].'</h1>
			</div>
		  </div>
		';
	}
	echo '</div>';
	  
	?>
    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
  
<div class="container-fluid text-center">    
  <h3>Upcoming Events</h3><br>
  <div class="row">
    <div class="col-sm-4">
      <img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive img-center" style="width:100%" alt="Image">
      <p>Current Project</p>
    </div>
    <div class="col-sm-4"> 
      <img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive img-center" style="width:100%" alt="Image">
      <p>Project 2</p>    
    </div>
    <div class="col-sm-4">
      <div class="well">
       <p>Some text..</p>
      </div>
      <div class="well">
       <p>Some text..</p>
      </div>
    </div>
  </div>
</div><br>



                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    
        <!-- Menu Toggle Script -->

</body>
    
 <?php include 'sidebarScripts.php';?>   
 
        
 
    

    
</html>
