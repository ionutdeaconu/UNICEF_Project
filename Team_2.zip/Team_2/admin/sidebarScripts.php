<!-- Add thia after the body tag-->
    
       

<!-- Resize scripts-->
    <script>
        var collapsed = 0;
        var manualControl = 0;
        (function($) {
    var $window = $(window),
        $html = $('html');

    function resize() {
        if ($window.width() < 768) {
            if (manualControl == 1) return;
            collapsed = 1;
              $("#wrapper").toggleClass("toggled");
                
            document.getElementById("element1").innerHTML = '<span class="glyphicon glyphicon-home center-icons"></span>';
            document.getElementById("element2").innerHTML = '<span class="glyphicon glyphicon-th-list center-icons"></span>';
            document.getElementById("element3").innerHTML = '<span class="glyphicon glyphicon-search center-icons"></span>';
            document.getElementById("element4").innerHTML = '<span class="glyphicon glyphicon-plus-sign center-icons"></span>';
            document.getElementById("element5").innerHTML = '<span class="glyphicon glyphicon-wrench center-icons "></span>';
            document.getElementById("element6").innerHTML = '<span class="glyphicon glyphicon-pencil center-icons"></span>';
            document.getElementById("element7").innerHTML = '<span class="glyphicon glyphicon-repeat center-icons"></span>';
            document.getElementById("element10").innerHTML = '<span class="glyphicon glyphicon-chevron-right center-icons" id="menu-toggle"></span>';
            
          
            return;
        }
            if (manualControl == 1) return;
            collapsed = 0;
            $("#wrapper").toggleClass("toggled", true);
            document.getElementById("element1").innerHTML = 'MoonLight Engine' ;
            document.getElementById("element2").innerHTML = 'Home';
            document.getElementById("element3").innerHTML = 'Events';
            document.getElementById("element4").innerHTML = 'Add Event';
            document.getElementById("element5").innerHTML = 'Change your Password';
            document.getElementById("element6").innerHTML = 'Add New User';
            document.getElementById("element7").innerHTML = 'Exit Admin Portal';
            document.getElementById("element10").innerHTML = '<span class="glyphicon glyphicon-chevron-left center-icons" id="menu-toggle"></span> Hide Sidebar';
            
          

    }

    $window
        .resize(resize)
        .trigger('resize');
})(jQuery);
    </script>

<!-- Manual Resize-->

<script>
    
    $(document).ready(function(){
        $("#element10").click(function(){
            manualControl = 1;
            
            if (collapsed == 0)
            {
               collapsed = 1;
              $("#wrapper").toggleClass("toggled");
                
            document.getElementById("element1").innerHTML = '<span class="glyphicon glyphicon-home center-icons"></span>';
            document.getElementById("element2").innerHTML = '<span class="glyphicon glyphicon-th-list center-icons"></span>';
            document.getElementById("element3").innerHTML = '<span class="glyphicon glyphicon-search center-icons"></span>';
            document.getElementById("element4").innerHTML = '<span class="glyphicon glyphicon-plus-sign center-icons"></span>';
            document.getElementById("element5").innerHTML = '<span class="glyphicon glyphicon-wrench center-icons "></span>';
            document.getElementById("element6").innerHTML = '<span class="glyphicon glyphicon-pencil center-icons"></span>';
            document.getElementById("element7").innerHTML = '<span class="glyphicon glyphicon-repeat center-icons"></span>';
            document.getElementById("element10").innerHTML = '<span class="glyphicon glyphicon-chevron-right center-icons" id="menu-toggle"></span>';
            
          
            return;
            }
            else
            {

            collapsed = 0;
            $("#wrapper").toggleClass("toggled", true);
            document.getElementById("element1").innerHTML = 'MoonLight Engine' ;
            document.getElementById("element2").innerHTML = 'Home';
            document.getElementById("element3").innerHTML = 'Events';
            document.getElementById("element4").innerHTML = 'Add Event';
            document.getElementById("element5").innerHTML = 'Change your Password';
            document.getElementById("element6").innerHTML = 'Add New User';
            document.getElementById("element7").innerHTML = 'Exit Admin Portal';
            document.getElementById("element10").innerHTML = '<span class="glyphicon glyphicon-chevron-left center-icons" id="menu-toggle"></span> Hide Sidebar';
            }
            
        
        
        });
    });
</script>
