<!DOCTYPE html>
<html lang="en">

        <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">
    
        <?php
		include 'sidebar.php';
		include 'session.php';
		include '../connectdb.php';
		$eventID = $_GET['eventID'];		
		$sql = "SELECT * FROM events WHERE EventID = '$eventID'";
		$result = $db->query($sql);
		while($row = $result->fetch_assoc()) {
			$eventID = $row['EventID'];
			
		?>
		
		<?php
			if (isset($_POST['EventName'])) {
				$eventName = $_POST["EventName"];
				$eventDescription = $_POST["EventDescription"];
				$organiserName = $_POST["OrganiserName"];
				$organiserDescription = $_POST["OrganiserDescription"];
				$startDate= $_POST['StartDate'];
				$startTime = $_POST['StartTime'];
				$venueName = $_POST['VenueName'];
				$venueRoute = $_POST['VenueRoute'];
				$addressL1 = $_POST['AddressL1'];
				$addressL2 = $_POST['AddressL2'];
				$city = $_POST['City'];
				$state = $_POST['State'];
				$country = $_POST['Country'];
				$postalCode = $_POST['PostalCode'];
				$numTickets = $_POST['NumTickets'];
				$featuredEvent = $_POST['FeaturedEvent'];
				$paypalEmail = $_POST['PaypalAcc'];
				$twitterAcc = $_POST['TwitterAcc'];
			
		
				$sql1 = "UPDATE events SET 
				EventName = '$eventName', 
				EventDescription = '$eventDescription',
				OrganiserName = '$organiserName',
				OrganiserDescription = '$organiserDescription',
				StartDate = '$startDate',
				StartTime = '$startTime',
				VenueName = '$venueName',
				VenueRoute = '$venueName',
				AddressL1 = '$addressL1',
				AddressL2 = '$addressL2',
				City = '$city',
				State = '$state',
				Country = '$country',
				PostalCode = '$postalCode',
				FeaturedEvent = '$featuredEvent',
				PaypalEmail = '$paypalEmail',
				TwitterAcc = '$twitterAcc'
				
				WHERE EventID = '$eventID'
				";
				
				if ($db->query($sql1) === TRUE) {
				}
				else{
					die("Error: " . $db->error);
				}
				
				for ($i=1; $i<$numTickets+1; $i++){
					$ticketName = $_POST['TicketName'.$i];
					$ticketAmount = $_POST['TicketAmount'.$i];
					$ticketPrice = $_POST['TicketPrice'.$i];
					$sql13 = "INSERT INTO tickets (TicketName, TicketsAvailable, TicketsSold, TicketPrice, EventID) VALUES
					('$ticketName', '$ticketAmount', '0', '$ticketPrice', '$eventID')";
					echo $sql13;
					if ($db->query($sql13) === TRUE) {
						header('Location:eventPage.php?eventID='.$eventID);
						//header("Refresh:0");
					}
					else {
						//echo ($sql13);
						echo("");
						die("Error: " . $db->error);
						
					}
				}
			}
		
		
		?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    
    <title>Edit your event</title>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    

    
    

</head>

<body>

    

      
        
   
            <div class="container-fluid">
                 <img class ="img-responsive img-center" src="../Images/EventBanner.png">
                
    <h1>Event Details</h1>

                

<form action="editEvent.php?eventID=<?php echo $eventID; ?>" method="post">

    <div class = "form-group">
    <label for="oname"><span class="label-req">*</span>Organiser name: </label>
        <input class = "form-control" type="text" id="oname" placeholder="Enter organiser name" name="OrganiserName" value ="<?php echo($row['OrganiserName']); ?>" required>
    </div>
    
    <div class = "form-group">
        <label for="odesc"><span class="label-req">*</span>Organiser description: </label>
        <input class = "form-control" type="text" id="odesc" placeholder="Enter description" name="OrganiserDescription" value ="<?php echo($row['OrganiserDescription']); ?>" required>
    </div>
    
    <div class = "form-group">
        <label for="title"><span class="label-req">*</span>Event title: </label>
        <input class = "form-control" type="text" id="title" placeholder="Enter event title" name="EventName"  value ="<?php echo($row['EventName']); ?>"required>
    </div>
    
    <div class = "form-group">
        <label for="edesc"><span class="label-req">*</span>Event description: </label>
        <textarea  rows ="5" class = "form-control" type="text" id="edesc" name="EventDescription" required><?php echo($row['EventDescription']); ?></textarea>
    </div>
    
    <div class = "form-group">
        <label for="bannerimg">Event banner: (1600x400) </label>
        <input class = "form-control" type="file" id="files" placeholder="Add banner" name="imageUpload" value ="<?php echo($row['BannerImage']); ?>">
    </div>
    
    <div class = "form-group">
        <label for="bannerimg">Event thumbnail: (200x200 max) </label>
        <input class = "form-control" type="file" id="files" placeholder="Add thumbnail" name="thumbnailUpload" value ="<?php echo($row['ThumbnailImage']); ?>">
    </div>
	
	<div class="checkbox">
  <label><input type="hidden" name="FeaturedEvent" id="FeaturedEvent" value="0"></label>
  <label><input type="checkbox" name="FeaturedEvent" id="FeaturedEvent" value="1" <?php if ($row['FeaturedEvent'] == 1){echo 'checked';} ?> >List as Featured Event (Displayed in Homepage)</label>
</div>
    

<hr>

<h2>Event time</h2>
    
    <div class = "form-group">
        <label for="tstart"><span class="label-req">*</span>Select a start date:</label>
        <input class = "form-control" type="text" id="tstart" placeholder="Enter a date, e.g.: 14/04/2017" name="StartDate" value ="<?php echo($row['StartDate']); ?>"required>
    </div>
    
        <div class = "form-group">
        <label for="tstart">Select an end date:</label>
        <input class = "form-control" type="text" id="tend" placeholder="Enter a date, e.g.: 15/04/2017" name="StartTime" value ="<?php echo($row['StartTime']); ?>" >
    </div>
    
    
   
    
    <hr>
    
    <h2>Venue Details</h2>
    
    <div class = "form-group">
    <label for="vname"><span class="label-req">*</span>Venue name: </label>
        <input class = "form-control" type="text" id="vname" placeholder="Enter venue name" name="VenueName" value ="<?php echo($row['VenueName']); ?>"required>
    </div>
    

    
    <div class = "form-group">
        <label for="indications">How to get there: </label>
        <textarea  rows ="5" class = "form-control" type="text" id="indications" placeholder="Please explain how to get there!" name="VenueRoute"><?php echo($row['VenueRoute']); ?></textarea>
    </div>
    
    <div class = "form-group">
    <label for="address1"><span class="label-req">*</span>Address Line 1: </label>
        <input class = "form-control" type="text" id="address1" placeholder="E.g: Gower Street 66, Euston" name="AddressL1" value ="<?php echo($row['AddressL1']); ?>" required>
    </div>
    
    <div class = "form-group">
    <label for="address2">Additional address details:</label>
        <input  class = "form-control" type="text" id="address2" placeholder="E.g: Floor 2, Room 23" name="AddressL2" value ="<?php echo($row['AddressL2']); ?>">
    </div>
    
    <div class = "form-group">
    <label for="city">City / Town:</label>
        <input class = "form-control" type="text" id="city" placeholder="Enter City / Town" name="City" value ="<?php echo($row['City']); ?>" >
    </div>
    
    <div class = "form-group">
    <label for="state">State / Province / Region: </label>
        <input class = "form-control" type="text" id="state" placeholder="Enter State / Province / Region" name="State" value ="<?php echo($row['State']); ?>" >
    </div>
    
    <div class = "form-group">
    <label for="pcode"><span class="label-req">*</span>ZIP/ Postal Code: </label>
        <input class = "form-control" type="text" id="pcode" placeholder="Enter ZIP / Postal Code" name="PostalCode" value ="<?php echo($row['PostalCode']); ?>"required>
    </div>
    
    <div class = "form-group">
    <label for="country"><span class="label-req">*</span>Country: </label>
	<input class = "form-control" type="text" id="pcode" placeholder="Enter Country" name="Country" value ="<?php echo($row['Country']); ?>"required>
    </div>
    <hr>
	
	<h2>Social &amp; PayPal</h2>
    
    <div class = "form-group">		
		<label for="twitterAcc"><span class="label-req">*</span>Link a Twitter Account: </label>
        <input class = "form-control" type="text" id="TwitterAcc" placeholder="Enter an Twitter handle, e.g:  @UNICEF" name="TwitterAcc" value ="<?php echo($row['TwitterAcc']); ?>" required>
    </div>
    
    <div class = "form-group">		
		<label for="paypal"><span class="label-req">*</span>Link to Seller PayPal Account: </label>
        <input class = "form-control" type="text" id="PaypalAcc" placeholder="Enter a valid PayPal account, e.g: example@domain.com" name="PaypalAcc" value ="<?php echo($row['PaypalEmail']); ?>" required>
    </div>

    <hr>
	
    <h2><span class="label-req">*</span>Tickets <button type="button" class="btn btn-success center-line" onclick="addPaidTicket()" >Add Ticket</button> <button type="button" class="btn btn-warning center-line" onclick="removeLast()" >Remove Last Ticket</button></h2>
    
<div class="ticket">       
      <div id="type"> 
	  
	  <?php 
	  
	    $ticketSql = "SELECT * FROM tickets WHERE EventID = '$eventID'";
		$ticketResult = $db->query($ticketSql);
		$count = mysqli_num_rows($ticketResult);
		$ticketnum = 0;
		$ticketIDs = array();
			while($trow = $ticketResult->fetch_assoc()) {
			$ticketnum +=1;
				echo '<div class = "form-group form-inline"><div class = "form-group"><label for="TicketName" class="form-control-label"><span class="label-req">*</span>Ticket Name</label><input required class = "form-control" type="text" id="TicketName" placeholder="E.g: Early Bird" name="TicketName'.$ticketnum.'" value ="'.$trow['TicketName'].'"></div><div class = "form-group"><label for="TicketAmount" class="form-control-label "><span class="label-req">*</span>Amount of tickets available</label><input required class = "form-control" type="text" id="TicketAmount" placeholder="E.g: 50" name="TicketAmount'.$ticketnum.'" value ="'.$trow['TicketsAvailable'].'"></div><div class = "form-group"><label for="TicketPrice" class="form-control-label "><span class="label-req">*</span>Ticket Price (£)</label><input required class = "form-control" type="text" id="TicketPrice" placeholder="E.g: 5" name="TicketPrice'.$ticketnum.'" value ="'.$trow['TicketPrice'].'"></div></div>';
				array_push($ticketIDs, $trow['TicketID']);
			}
		/*for($i=0; $i<count($ticketIDs); $i++){
			$remove = $ticketIDs[$i];
			$sql5 = "DELETE FROM tickets WHERE TicketID = '$remove'";
			if ($db->query($sql5) === TRUE) {
						//header("Refresh:0");
			}
			else {
				echo ($sql);
				echo("");
				die("Error: " . $db->error);
				
			}
			
		}*/
			
	  ?>
	  
      </div>
    </div>
	
	<p id="demo"></p>
	
	<p id="paid"></p>
    
	<script>
	

	
	
	
	
	  var paid = <?php echo $ticketnum; ?>;
	  function addPaidTicket() {    
		$('<div class = "form-group form-inline"><div class = "form-group"><label for="TicketName' + ++paid + '" class="form-control-label"><span class="label-req">*</span>Ticket Name</label><input required class = "form-control" type="text" id="TicketName" placeholder="E.g: Early Bird" name="TicketName'+ paid + '"></div><div class = "form-group"><label for="TicketAmount'+ paid + '" class="form-control-label "><span class="label-req">*</span>Amount of tickets available</label><input required class = "form-control" type="text" id="TicketAmount" placeholder="E.g: 50" name="TicketAmount'+ paid + '"></div><div class = "form-group"><label for="TicketPrice'+ paid + '" class="form-control-label "><span class="label-req">*</span>Ticket Price (£)</label><input required class = "form-control" type="text" id="TicketPrice" placeholder="E.g: 5" name="TicketPrice'+ paid + '"></div></div>') .appendTo("#type");
		document.getElementById("demo").innerHTML = ('<input type="hidden" name="NumTickets" id="NumTickets" value="' + paid + '">');
		//document.write('<input type="hidden" name="NumTickets" id="NumTickets" value="' + paid + '">');
	  }       
	  
	  function removeLast() {
		var lastChild = document.getElementById("type").lastChild;
		lastChild.parentNode.removeChild(lastChild);
		
		if(paid == 0)
            {
                return;
            }
        else
            {
                paid--;
            }
          
		document.getElementById("demo").innerHTML = ('<input type="hidden" name="NumTickets" id="NumTickets" value="' + paid + '">');
		//document.getElementById("demo").innerHTML = paid;
	  }
	  
	  document.getElementById("demo").innerHTML = ('<input type="hidden" name="NumTickets" id="NumTickets" value="' + paid + '">');
	  
	  /*var div = document.createElement('div');
	  //div.innerHTML = '<input type="hidden" name="NumTickets" id="NumTickets" value="' + paid + '">';
	  document.body.appendChild(div);
	  document.write('<input type="hidden" name="NumTickets" id="NumTickets" value="' + paid + '">');
	  document.getElementById("demo").innerHTML = paid; */
	  
	  
	</script>
    
    <hr>
    <button type="submit" class="btn btn-primary center-block">Save Changes</button><br>
    <button function="delete.php" class="btn btn-danger center-block">Delete Event</button>
  </form>
    

            </div>

        </div> 
            
 


    
            

    <hr>
    
          
   
                        
   
 
        <!-- /#page-content-wrapper -->

  
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    
		<?php } ?>

</body>

<?php include 'sidebarScripts.php';?>
    

</html>
