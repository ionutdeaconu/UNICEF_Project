<!DOCTYPE html>
<html lang="en">


    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">


<?php
   include("../connectdb.php");
   include("session.php");
   include("sidebar.php");
   
   $error = "";
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = $_SESSION['login_user'];
      $mypassword = mysqli_real_escape_string($db,$_POST['oldpassword']); 
	  $newpassword = mysqli_real_escape_string($db,$_POST['password']);
      
      $sql = "SELECT AdminID FROM admin WHERE username = '$myusername' and password = '$mypassword'";
      $result = $db->query($sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
	  if($count == 1) {
		  
		if ($_POST['password'] == $_POST['confpassword']){
			$sql = "UPDATE admin SET password = '$newpassword' WHERE username = '$myusername'";
			if ($db->query($sql) === TRUE) {
				header('Location:index.php');
			}
			else{
				$error.=("Error: " . $db->error);
			}
		}
		else{
		  $error .= "Passwords do not match";
		} 
        
      }else {
         $error .= "Invalid Old Password Entered";
      }
   }
?>
<html>
   
   <head>
      <title>Login to Moonlight</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      
   </head>
   <br/><br/>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Change your Password</b></div>
				
            <div style = "margin:30px">
               
               <form action = "" method = "post">
                  <label>Enter Old Password: </label><br/><input type = "password" name = "oldpassword" class = "box"/><br /><br />
                  <label>New Password: </label><br/><input type = "password" name = "password" class = "box" /><br/><br />
				  <label>Confirm Password: </label><br/><input type = "password" name = "confpassword" class = "box" /><br/><br /><br/>
                  <input type = "submit" value = " Submit "/><br />
               </form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
					
            </div>
				
         </div>
			
      </div>

   </body>
    
    <?php include 'sidebarScripts.php';?>
</html>