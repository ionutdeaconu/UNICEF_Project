<!DOCTYPE html>
<html lang="en">


<?php
include 'sidebar.php';
include 'session.php';
?>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">


<head><br/>
</head>

<body>
<h2>&nbsp&nbspWelcome to UNICEF Moonlight's Admin Portal. Use the sidebar to manage this web application.</h2>
</body>