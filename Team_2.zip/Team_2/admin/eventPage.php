<!DOCTYPE html>
<html lang="en">

        <?php
		include 'sidebar.php';
		include 'session.php';
		include '../connectdb.php';
		$eventID = $_GET['eventID'];		
		$sql = "SELECT * FROM events WHERE EventID = '$eventID'";
		$result = $db->query($sql);
		while($row = $result->fetch_assoc()) {
			$eventID = $row['EventID'];
			
		?>
		
		<?php
		
			
			if (isset($_POST['mediaposted'])) {
			$root = "../";
			$target_dir = "uploads/";
			$target_file = $root.$target_dir ."media-zip".$eventID.".zip";
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

			if (move_uploaded_file($_FILES["mediaUpload"]["tmp_name"], $target_file)){
				$thumbnailImage=($target_dir.basename($_FILES["mediaUpload"]["name"]));
				//echo 'success';
			}
			else{
				$thumbnailImage='';
				//echo 'fail';
			}
			
			}
		
		
		?>
		
		
		
		

<head>



    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!--Google Sign in-->
    <meta name="google-signin-client_id" content="1072977554166-st43ulc96co7ldgmc609fvukufj67c0h.apps.googleusercontent.com">

    <title>Moonlight: <?php echo($row['EventName']); ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    
    <!--Social Media Scripts-->
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.9";
  fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>
    
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)          [0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');
    </script>

    <!--Social Media Scripts-->
              
        <div class="container-fluid">
            
                <img class ="img-responsive img-center" src="../<?php echo($row['BannerImage']); ?>">
           
            <div class="row">
                <div class="col-md-8 col-sm-8">
                
                       <h1 id="EventID"><?php echo($row['EventName']); ?>

							<a class="btn btn-warning center-line" href="editEvent.php?eventID=<?php echo $eventID?>">Admin Page</a>
							<a class="btn btn-warning center-line" href="transactions.php?eventID=<?php echo $eventID?>">View Transactions</a>
                        </h1>
                        <p> <?php echo($row['EventDescription']); ?> </p>

                 </div>
                <div class="col-md-4 col-sm-4 addInfo">
                <h1>Overview</h1>
                <p><span class="glyphicon glyphicon-calendar"></span> <?php echo($row['StartDate'].' '.$row['StartTime']); ?><br>
                    <span class="glyphicon glyphicon-map-marker"></span> <?php echo($row['AddressL1']); ?><br>
                    <span class="glyphicon glyphicon-user"></span> <?php echo($row['OrganiserName']); ?><br>
                    <a href="https://twitter.com/share" class="twitter-share-button" data-text="Check this event!" data-via="OrganiserTweeter" data-size="large" data-hashtags="MoonlightEngine">Tweet</a> 
                    <div class="fb-share-button" data-href="https://developers.facebook.com/docs/plugins/" data-layout="button" data-size="large" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="Event URL Here">Share</a></div>
                    
                    <br><br>
                        
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#purchaseModal">Buy Tickets</button></p>
                                
            </div>
            
            </div>

        
    <div class="row">
        <div class="col-sm-12">
        <hr>
        <h1>How to get there</h1>
        </div>
    </div>        
 
   
    <div class="row">
        <div class ="col-md-5 col-lg-6 col-sm-12">
                    <p id="route"><?php echo($row['VenueRoute']); ?></p>
            <div class="">
                <div class="center-div">
                    <h3 style="font-size: 18px;">Media from the event </h3>
                    <a class="media-dl btn btn-success center-line" href="../uploads/media-zip<?php echo $eventID; ?>.zip" download>
                       <span class="glyphicon glyphicon-download-alt"></span>
                    </a>
                    <a class="media-dl btn btn-warning center-line" data-toggle="modal" data-target="#mediaModal">
                       <span class="glyphicon glyphicon-upload"></span>
                    </a>
                </div>

            </div>

                    </p>
        </div>

                <div class= "col-lg-6 col-md-7 col-sm-12">
                    <hr>    
                    <h1> </h1>
                   <iframe id="map" class ="event-map" src="https://maps.google.it/maps?q=<?php echo htmlspecialchars($row['AddressL1']); ?>); ?>&output=embed" width="100%" frameborder="0" style="border:0 " allowfullscreen></iframe>
                </div>
   
    
      

        </div>
    </div>
                
 
                        
   
 
        <!-- /#page-content-wrapper -->

  
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

              <script>
                var height = document.getElementById('#route').style.height;
                document.getElementById('#map').style.height= height;
                alert("height is " + height);
            </script>

</body>
<?php include 'sidebarScripts.php';?>

<!-- Pull Down Script http://jsfiddle.net/jhfrench/bAHfj/ --> 
<script>
$('.pull-down').each(function() {
  var $this=$(this);
	$this.css('margin-top', $this.parent().height()-$this.height())
});
</script>



<!-- Modal - Media Upload --> 

    <div id="mediaModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Media Upload</h4>
      </div>
      <div class="modal-body">
           <h1>Upload files:</h1>
          <form action="eventPage.php?eventID=<?php echo $eventID; ?>" method="post" enctype="multipart/form-data">
			
              <div class = "form-group">       
                    <input class = "form-control" type="file" id="mediaUpload" placeholder="Add Files" name="mediaUpload">
              </div>
              <input type="hidden" name="mediaposted" value="1" />
              <button type="submit" class="btn btn-success center-block">Upload Files</button>
          </form>
        

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
      </div>
    </div>
        </div>
    </div>

<!-- End Media Upload --> 




    
        <!-- Modal - Purchase -->
<div id="purchaseModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->


    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Ticket Purchase Window</h4>
      </div>
      <div class="modal-body">
           <h1>Register</h1>
        <p>Select a ticket and proceed to Paypal.</p>
		
	  <form class="paypal" action="PaypalCode/payments.php" method="post" id="paypal_form" target="_blank">
	  
	  <div class="form-group">
		  <label for="TicketID">Select ticket:</label>
		  <select class="form-control" id="TicketID" name="TicketID">
			<?php
			$ticketSql = "SELECT * FROM tickets WHERE EventID = '$eventID'";
			$ticketResult = $db->query($ticketSql);
			while($tRow = $ticketResult->fetch_assoc()) {
				if (($tRow['TicketsAvailable']-$tRow['TicketsSold']) >0){
					echo'<option value="'.$tRow['TicketID'].'">'.$tRow['TicketName'].' --------- £'.$tRow['TicketPrice'].'</option>';
					$ticketID = $tRow['TicketID'];
					$ticketName = $tRow['TicketName'];
					$ticketPrice = $tRow['TicketPrice'];
				}
				else {
					echo'<option disabled>'.$tRow['TicketName'].' --------- £'.$tRow['TicketPrice'].' --------- SOLD OUT'.'</option>';
				}
			}
			
			?>
		   </select>
		</div>
		  
		<input type="hidden" name="cmd" value="_xclick" />
		<input type="hidden" name="no_note" value="100" />
		<input type="hidden" name="lc" value="UK" />
		<input type="hidden" name="currency_code" value="GBP" />
		<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
		<input type="hidden" name="sellerEmail" value="<?php echo($row['PaypalEmail']); ?>"  />
		<input type="hidden" name="eventID" value="<?php echo $eventID; ?>" />
		<input type="hidden" name="eventName" value="<?php ($row['EventName']); ?>" />
		
		<p id="hiddenfields"></p>
		
		<p id="purchaseButton"></p>
		
		<script>
			document.getElementById("hiddenfields").innerHTML = '<input type="hidden" name="name" value="Customers First Name"  /><input type="hidden" name="payerEmail" value="customer@example.com"  />';
			document.getElementById("purchaseButton").innerHTML = '<input type="submit" name="submit" value="LOG IN FIRST" disabled/>';
		</script>
		
		
	</form>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
      </div>
    </div>
    </div>
    </div>
      
      
      
    

	
	<?php } ?>



</html>
