<!DOCTYPE html>
<html lang="en">

<?php include 'session.php';?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <?php include 'sidebar.php';?>

    <title>All Events</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

 

      
        
             
            <div class="container-fluid">
                
                <img class ="img-responsive banner-img" src="../Images/EventBanner.png">
                

<div class="container">
    <div class="row">
        <h1 class="center-block">List of Events</h1>
		
		<?php
		include '../connectdb.php';	
		$sql = "SELECT * FROM events ORDER BY EventID DESC";
		$result = $db->query($sql);
		while($row = $result->fetch_assoc()) {
			echo '
		
		
		
        <div class=  "col-sm-4" "col-xs-6">
            <div class="thumbnail">
                <a href="#">   
                    <img src="../'.$row['ThumbnailImage'].'">
                </a>
                <div class="caption">
                    <h3>'.$row['EventName'].'</h3>
                    <p><span class="glyphicon glyphicon-calendar"></span>'.$row['StartDate'].' '.$row['StartTime'].'<br>
                    <span class="glyphicon glyphicon-map-marker"></span>'.$row['AddressL1'].'<br>
                    <span class="glyphicon glyphicon-user"></span>'.$row['OrganiserName'].'<br>
                        <a href ="eventPage.php?eventID='.$row['EventID'].'" class="btn btn-success center-block" >View Event</a>   

                    </p>
                </div>
            </div>    
        </div>
		
		';
		}
		?>
                
            </div> 
</div>

            
    <hr>
    
          
   
                        
   
 
        <!-- /#page-content-wrapper -->

  
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    
    </div>
</body>
    <?php include 'sidebarScripts.php';?>
    

	


</html>
