<?php

//IF DOING REAL PAYPAL REMOVE THE 'sandbox' bit inside ALL URLS.

session_start();

include '../connectdb.php';


$_SESSION['ticketID'] = $_POST['TicketID'];
$ticketID = $_POST['TicketID'];
$sql = "SELECT * FROM tickets WHERE TicketID = '$ticketID'";
$result = $db->query($sql);
while($row = $result->fetch_assoc()) {
	$_SESSION['ticketName'] = $row['TicketName'];
	$_SESSION['ticketPrice'] = $row['TicketPrice'];
}

$_SESSION['eventID'] = $_POST['eventID'];
$_SESSION['eventName'] = $_POST['eventName'];
$_SESSION['customerName'] = $_POST['name'];
$_SESSION['customerEmail'] = $_POST['payerEmail'];
$_SESSION['paypalEmail'] = $_POST['sellerEmail'];


// PayPal settings
$return_url = 'http://moonlightenginedemo.azurewebsites.net/team_2/paypalCode/payment-successful.php';
$cancel_url = 'payment-cancelled.html';
$notify_url = 'payments.php';

$item_name = $_SESSION['ticketName'].' '.$_SESSION['eventName'];

$item_amount = $_SESSION['ticketPrice'];

// Include Functions
include("functions.php");

// Check if paypal request or response
if (!isset($_POST["txn_id"]) && !isset($_POST["txn_type"])){
	$querystring = '';
	
	// Firstly Append paypal account to querystring
	$querystring .= "?business=".urlencode($_SESSION['paypalEmail'])."&";
	
	// Append amount& currency (£) to querystring so it cannot be edited in html
	
	//The item name and amount can be brought in dynamically by querying the $_POST['item_number'] variable.
	$querystring .= "item_name=".urlencode($item_name)."&";
	$querystring .= "amount=".urlencode($item_amount)."&";
	
	//loop for posted values and append to querystring
	foreach($_POST as $key => $value){
		$value = urlencode(stripslashes($value));
		$querystring .= "$key=$value&";
	}
	
	// Append paypal return addresses
	$querystring .= "return=".urlencode(stripslashes($return_url))."&";
	$querystring .= "cancel_return=".urlencode(stripslashes($cancel_url))."&";
	$querystring .= "notify_url=".urlencode($notify_url);
	
	// Append querystring with custom field
	//$querystring .= "&custom=".USERID;
	
	// Redirect to paypal IPN
	header('location:https://www.sandbox.paypal.com/cgi-bin/webscr'.$querystring);
	exit();
} else {
	header('http://www.google.com');
	// Response from Paypal

	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	foreach ($_POST as $key => $value) {
		$value = urlencode(stripslashes($value));
		$value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i','${1}%0D%0A${3}',$value);// IPN fix
		$req .= "&$key=$value";
	}

	
	// assign posted variables to local variables
	$data['item_name']			= $_POST['item_name'];
	$data['item_number'] 		= $_POST['item_number'];
	$data['payment_status'] 	= $_POST['payment_status'];
	$data['payment_amount'] 	= $_POST['mc_gross'];
	$data['payment_currency']	= $_POST['mc_currency'];
	$data['txn_id']				= $_POST['txn_id'];
	$data['receiver_email'] 	= $_POST['receiver_email'];
	$data['payer_email'] 		= $_POST['payer_email'];
	$data['custom'] 			= $_POST['custom'];
		
	// post back to PayPal system to validate
	$header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
	$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
	
	$fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);
	
	if (!$fp) {
		// HTTP ERROR
		
	} else {
		fputs($fp, $header . $req);
		while (!feof($fp)) {
			$res = fgets ($fp, 1024);
			if (strcmp($res, "VERIFIED") == 0) {
				
				header('http://www.google.com');

				include '../connectdb.php';	
				$customerName = $_SESSION['customerName'];
				$customerEmail = $_SESSION['customerEmail'];
				$ticketID = $_SESSION['ticketID'];
				$ticketName = $_SESSION['ticketName'];
				$ticketPrice = $_SESSION['ticketPrice'];
				$eventID = $_SESSION['eventID'];
				$eventName = $_SESSION['eventName'];
				$transferredTo = $_SESSION['paypalEmail'];
								
				$sql = "INSERT INTO Transactions (CustomerName, CustomerEmail, TicketID, TicketName, TicketPrice, EventID, EventName, TransferredTo)
				VALUES ('$customerName', '$customerEmail', '$ticketID', '$ticketName', '$ticketPrice', '$eventID', '$eventName', '$transferredTo')";
				if ($db->query($sql) === TRUE) {
				}
				else{
					echo ($sql);
					echo("");
					die("Error: " . $db->error);
				}
			
			} else if (strcmp ($res, "INVALID") == 0) {
			
				// PAYMENT INVALID & INVESTIGATE MANUALY!
				// E-mail admin or alert user
				
				// Used for debugging
				//@mail("user@domain.com", "PAYPAL DEBUGGING", "Invalid Response<br />data = <pre>".print_r($post, true)."</pre>");
			}
		}
	fclose ($fp);
	}
}

?>
