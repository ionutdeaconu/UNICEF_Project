<!DOCTYPE html>
<html>
<head>

<!DOCTYPE html>
<html lang="en">


<?php
include '../sidebar.php';
?>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/styles.css" rel="stylesheet">


<?php
	session_start();
	
		include '../connectdb.php';	
		$customerName = $_SESSION['customerName'];
		$customerEmail = $_SESSION['customerEmail'];
		$ticketID = $_SESSION['ticketID'];
		$ticketName = $_SESSION['ticketName'];
		$ticketPrice = $_SESSION['ticketPrice'];
		$eventID = $_SESSION['eventID'];
		$eventName = $_SESSION['eventName'];
		$transferredTo = $_SESSION['paypalEmail'];
						
		$sql = "INSERT INTO Transactions (CustomerName, CustomerEmail, TicketID, TicketName, TicketPrice, EventID, EventName, TransferredTo)
		VALUES ('$customerName', '$customerEmail', '$ticketID', '$ticketName', '$ticketPrice', '$eventID', '$eventName', '$transferredTo')";
		if ($db->query($sql) === TRUE) {
		}
		else{
			echo ($sql);
			echo("");
			die("Error: " . $db->error);
		}
		
		header('Location:../index.php');
?>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">	
	<title>Payment Successful</title>
</head>
<body>
	<h1>Thank You</h1>
	<p>Your payment has been successful. Thank you.</p>
</body>
</html>
